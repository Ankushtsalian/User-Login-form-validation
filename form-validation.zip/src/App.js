import "./styles.css";
import Form from "./Components/Form";
export default function App() {
  return (
    <div className="App">
      <Form />
    </div>
  );
}
